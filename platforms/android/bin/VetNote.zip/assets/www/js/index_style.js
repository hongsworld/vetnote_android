$(document).ready(function (){


  //index
  $("iframe.main_frame").css("height","100%").css("height","-=60px");



});

