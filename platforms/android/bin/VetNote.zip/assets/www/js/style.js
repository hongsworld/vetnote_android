$(document).ready(function (){

  //로그북 사진 가로 세로 맞게
  var cw = $('div.new_camera_ic').height();
  $('div.new_camera_ic').css({'width':cw+'px'});
  width = $(window).width()
  /*
  $("div.calender_box").css("width",width - 26.5);
  $("div.calender_box.tappable-active").css("width",width - 26.5);
  $("div.new_logbook").css("width", width - 25);
  $("div.new_text_box").css("width", width - 178);
  $("div.new_text_box_mine").css("width", width - 178);
  alert($("div.new_text_box").width());
  $("div.each_log_list").css("width","100%").css("width","-=26");
  //$("div.each_log_list_rt").css("height", - 63);
  $("div.log_detail_body_box").css("width", width - 26);
  //$("div.log_detail_camera_box").css("width", width - 25);
  //$("div.log_detail_case_box").css("width", width - 25);
  //$("div.log_detail_case_lt").css("width", width/2 - 2);
  $("div.comment_box").css("width", width - 26);
  $("div.each_notice_top").css("width",width - 26);
  $("div.each_notice").css("width", width - 26);
  $("div.detail_notice_title").css("width", width - 26);
  $("div.notice_box").css("width", width -26);
  $("div.detail_picture_box-none").css("width", width - 25);
  $("div.detail_picture_box").css("width", width - 25);
  $("div.each_colum").css("width", width - 25);
  $("div.colum_line").css("width", width - 25);
  $("div.each_evaluation_colum").css("width", width - 26);
  $("div.each_evaluation_colum_rt").css("width", width - 41);
  $("div.each_evaluation_colum_rt1").css("width", width - 20);
  $("div.each_menu_rt").css("width", width - 40);
  */
});

